package com.example.carromaim

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var board: BoardView
    private lateinit var info: TextView
    private lateinit var modeLabel: TextView
    private var selectedMode = BoardView.Mode.STRIKER
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            contentResolver.openInputStream(it)?.use { stream ->
                val bmp = BitmapFactory.decodeStream(stream)
                board.setBitmap(bmp)
                info.text = "Image loaded. Tap the striker, then target coin, then pocket."
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }
        val title = TextView(this).apply {
            text = "CARROM AIM ASSISTANT"
            textSize = 20f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            setPadding(4, 8, 4, 8)
        }
        root.addView(title)
        val upload = Button(this).apply { text = "1. Load game screenshot"; setOnClickListener { pickImage.launch("image/*") } }
        root.addView(upload)
        modeLabel = TextView(this).apply {
            text = "Select: STRIKER"; textSize = 15f; setTextColor(Color.DKGRAY)
            setPadding(4, 8, 4, 8)
        }
        root.addView(modeLabel)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun modeButton(label: String, mode: BoardView.Mode) {
            modes.addView(Button(this).apply {
                text = label
                setOnClickListener {
                    selectedMode = mode
                    board.mode = mode
                    modeLabel.text = "Select: ${mode.name} — tap the matching point on image"
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        modeButton("Striker", BoardView.Mode.STRIKER)
        modeButton("Target", BoardView.Mode.TARGET)
        modeButton("Pocket", BoardView.Mode.POCKET)
        root.addView(modes)
        val second = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        second.addView(Button(this).apply {
            text = "Add coin"
            setOnClickListener { board.mode = BoardView.Mode.EXTRA; modeLabel.text = "Select: OTHER COIN — tap a coin" }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        second.addView(Button(this).apply {
            text = "Undo"
            setOnClickListener { board.undoPoint(); info.text = "Last point removed." }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        second.addView(Button(this).apply {
            text = "Clear"
            setOnClickListener { board.clearPoints(); info.text = "Points cleared." }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(second)
        board = BoardView(this)
        board.onPointChanged = { refreshInfo() }
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        val calculate = Button(this).apply {
            text = "CALCULATE BEST SHOT"
            textSize = 16f
            setOnClickListener { refreshInfo(true) }
        }
        root.addView(calculate)
        info = TextView(this).apply {
            text = "Load a screenshot to begin. This app uses manual point selection for reliable positioning."
            textSize = 13f; setTextColor(Color.BLACK)
            setPadding(8, 8, 8, 8)
        }
        root.addView(info)
        val help = TextView(this).apply {
            text = "Tip: mark the centre of striker and coin, then choose the pocket. Set coin diameter in the next version/calibration; current ghost-ball estimate uses board width."
            textSize = 11f; setTextColor(Color.DKGRAY); setPadding(8, 4, 8, 4)
        }
        root.addView(help)
        setContentView(root)
    }

    private fun refreshInfo(calculate: Boolean = false) {
        if (!::info.isInitialized) return
        val result = board.calculate()
        info.text = if (result == null) {
            "Set all 3 points: STRIKER → TARGET coin → POCKET."
        } else {
            val base = "Striker → ghost point: ${fmt(result.strikerDistance)} px\n" +
                "Target → pocket: ${fmt(result.pocketDistance)} px\n" +
                "Aim angle: ${fmt(result.aimAngle)}° | Cut angle: ${fmt(result.cutAngle)}°\n" +
                "Estimated ghost-ball offset: ${fmt(result.ghostOffset)} px\n" +
                "Direct path: ${if (result.clearLine) "geometrically clear" else "possible obstruction — check other coins"}"
            if (calculate) base + "\n\nBEST SHOT: Direct geometry selected. Check the drawn line against other coins and game physics before shooting." else base
        }
    }

    private fun fmt(v: Double) = String.format("%.1f", v)
}

private data class ShotResult(
    val strikerDistance: Double, val pocketDistance: Double,
    val aimAngle: Double, val cutAngle: Double,
    val ghostOffset: Double, val clearLine: Boolean
)

class BoardView(context: android.content.Context) : View(context) {
    enum class Mode { STRIKER, TARGET, POCKET, EXTRA }
    var mode = Mode.STRIKER
    var onPointChanged: (() -> Unit)? = null
    private var bitmap: Bitmap? = null
    private var striker: PointF? = null
    private var target: PointF? = null
    private var pocket: PointF? = null
    private val extras = mutableListOf<PointF>()
    private var scale = 1f
    private var dx = 0f
    private var dy = 0f
    private var imageRect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setBitmap(b: Bitmap) {
        bitmap = b
        clearPoints()
        invalidate()
    }
    fun clearPoints() { striker = null; target = null; pocket = null; extras.clear(); invalidate(); onPointChanged?.invoke() }
    fun undoPoint() {
        when {
            extras.isNotEmpty() -> extras.removeAt(extras.lastIndex)
            pocket != null -> pocket = null
            target != null -> target = null
            striker != null -> striker = null
        }
        invalidate(); onPointChanged?.invoke()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(225, 225, 225))
        val b = bitmap
        if (b == null) {
            p.color = Color.DKGRAY; p.textSize = 38f
            canvas.drawText("Load screenshot", 35f, height / 2f, p)
            return
        }
        val s = min(width.toFloat() / b.width, height.toFloat() / b.height)
        scale = s
        val w = b.width * s; val h = b.height * s
        dx = (width - w) / 2f; dy = (height - h) / 2f
        imageRect.set(dx, dy, dx + w, dy + h)
        canvas.drawBitmap(b, null, imageRect, p)
        val save = canvas.save()
        canvas.clipRect(imageRect)
        // Aim construction
        val a = striker; val t = target; val q = pocket
        if (a != null && t != null && q != null) {
            val unit = unit(t, q)
            val ghost = PointF(t.x - unit.x * coinRadius(), t.y - unit.y * coinRadius())
            drawLine(canvas, a, ghost, Color.YELLOW, 5f)
            drawLine(canvas, t, q, Color.GREEN, 4f)
            drawDashed(canvas, ghost, t, Color.CYAN)
            drawCircle(canvas, ghost, 10f, Color.CYAN)
            // Alternate one-cushion bank candidates by reflecting pocket around each image edge
            val candidates = listOf(
                PointF(-q.x, q.y), PointF(2*b.width-q.x, q.y),
                PointF(q.x, -q.y), PointF(q.x, 2*b.height-q.y)
            )
            for (r in candidates) {
                val v = unit(t, r)
                val g = PointF(t.x-v.x*coinRadius(), t.y-v.y*coinRadius())
                val bank = reflectToEdge(t, r, b.width.toFloat(), b.height.toFloat())
                if (bank != null) {
                    drawDashed(canvas, t, bank, Color.MAGENTA)
                }
            }
        }
        striker?.let { marker(canvas, it, "S", Color.YELLOW) }
        target?.let { marker(canvas, it, "T", Color.CYAN) }
        pocket?.let { marker(canvas, it, "P", Color.GREEN) }
        extras.forEach { marker(canvas, it, "•", Color.RED) }
        canvas.restoreToCount(save)
    }

    private fun mapPoint(pt: PointF) = PointF(dx + pt.x * scale, dy + pt.y * scale)
    private fun unmap(x: Float, y: Float) = PointF((x-dx)/scale, (y-dy)/scale)
    private fun marker(c: Canvas, pt: PointF, label: String, color: Int) {
        val v = mapPoint(pt); p.color = color; p.style = Paint.Style.STROKE; p.strokeWidth = 4f
        c.drawCircle(v.x, v.y, 12f, p)
        p.style = Paint.Style.FILL; p.textSize = 23f; c.drawText(label, v.x+13f, v.y-12f, p)
    }
    private fun drawLine(c: Canvas, a: PointF, b: PointF, color: Int, width: Float) {
        val x=mapPoint(a); val y=mapPoint(b); p.color=color; p.strokeWidth=width; p.style=Paint.Style.STROKE
        c.drawLine(x.x,x.y,y.x,y.y,p); p.style=Paint.Style.FILL
    }
    private fun drawDashed(c: Canvas, a: PointF, b: PointF, color: Int) {
        val x=mapPoint(a); val y=mapPoint(b); p.color=color; p.strokeWidth=3f
        p.pathEffect=DashPathEffect(floatArrayOf(12f,9f),0f); c.drawLine(x.x,x.y,y.x,y.y,p); p.pathEffect=null
    }
    private fun drawCircle(c: Canvas, pt: PointF, radius: Float, color: Int) {
        val v=mapPoint(pt); p.color=color; p.style=Paint.Style.STROKE; p.strokeWidth=3f
        c.drawCircle(v.x,v.y,radius,p); p.style=Paint.Style.FILL
    }
    private fun unit(a: PointF, b: PointF): PointF {
        val x=b.x-a.x; val y=b.y-a.y; val d=hypot(x,y).coerceAtLeast(0.001f)
        return PointF(x/d,y/d)
    }
    private fun coinRadius(): Float = (bitmap?.width ?: 1000) * 0.018f
    private fun reflectToEdge(a: PointF, reflectedPocket: PointF, w: Float, h: Float): PointF? {
        val vx=reflectedPocket.x-a.x; val vy=reflectedPocket.y-a.y
        if (abs(vx)>abs(vy)) {
            val edgeX=if(vx<0) 0f else w
            val tt=(edgeX-a.x)/vx
            return if(tt in 0f..1f) PointF(edgeX,a.y+vy*tt) else null
        } else {
            val edgeY=if(vy<0) 0f else h
            val tt=(edgeY-a.y)/vy
            return if(tt in 0f..1f) PointF(a.x+vx*tt,edgeY) else null
        }
    }
    fun calculate(): ShotResult? {
        val a=striker ?: return null; val t=target ?: return null; val q=pocket ?: return null
        val u=unit(t,q)
        val ghost=PointF(t.x-u.x*coinRadius(), t.y-u.y*coinRadius())
        val aim=atan2((ghost.y-a.y).toDouble(),(ghost.x-a.x).toDouble())*180/Math.PI
        val targetDir=atan2((q.y-t.y).toDouble(),(q.x-t.x).toDouble())
        val strikerDir=atan2((t.y-a.y).toDouble(),(t.x-a.x).toDouble())
        var cut=abs((targetDir-strikerDir)*180/Math.PI)%360.0
        if(cut>180) cut=360-cut
        val dist=hypot((ghost.x-a.x).toDouble(),(ghost.y-a.y).toDouble())
        val pd=hypot((q.x-t.x).toDouble(),(q.y-t.y).toDouble())
        val clear=extras.none { distanceToSegment(it,a,ghost) < coinRadius()*1.4 }
        return ShotResult(dist,pd,((aim%360)+360)%360,cut,coinRadius().toDouble(),clear)
    }
    private fun distanceToSegment(p: PointF,a: PointF,b: PointF): Double {
        val vx=b.x-a.x; val vy=b.y-a.y
        val len=vx*vx+vy*vy
        if(len==0f) return hypot((p.x-a.x).toDouble(),(p.y-a.y).toDouble())
        val t=(((p.x-a.x)*vx+(p.y-a.y)*vy)/len).coerceIn(0f,1f)
        return hypot((p.x-(a.x+t*vx)).toDouble(),(p.y-(a.y+t*vy)).toDouble())
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if(event.action==MotionEvent.ACTION_UP && imageRect.contains(event.x,event.y)) {
            val pt=unmap(event.x,event.y)
            when(mode) {
                Mode.STRIKER -> striker=pt
                Mode.TARGET -> target=pt
                Mode.POCKET -> pocket=pt
                Mode.EXTRA -> extras.add(pt)
            }
            invalidate(); onPointChanged?.invoke(); return true
        }
        return true
    }
}
